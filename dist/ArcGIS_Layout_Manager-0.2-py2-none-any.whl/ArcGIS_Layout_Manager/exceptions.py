class MXD_ERROR(Exception):
    pass


class LayoutExists(Exception):
    pass


class MissingLayout(Exception):
    pass
