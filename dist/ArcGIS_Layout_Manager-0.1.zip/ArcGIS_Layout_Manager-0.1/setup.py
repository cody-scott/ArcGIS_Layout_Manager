from setuptools import setup

setup(
    name='ArcGIS_Layout_Manager',
    version='0.1',
    description='Helper for supporting multiple layouts in ArcGIS layout view',
    url='',
    author='Cody Scott',
    author_email='',
    license='MIT',
    packages=['ArcGIS_Layout_Manager'],
    zip_safe=False
)
